"use client";

import Chatbox from "../components/Chatbox";

const ChatMessages = () => {
    return (
        <section className="section py-16">
            <div className="max-w-7xl mx-auto">
                <Chatbox />
            </div>
        </section>
    );
};

export default ChatMessages;
