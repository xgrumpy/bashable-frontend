import { ReactNode } from "react";
import type { Metadata } from "next";
import { AuthProvider } from "@/context/authContext";
import "../styles/globals.css";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "easymde/dist/easymde.min.css";
import "react-phone-number-input/style.css";
import { AppProvider } from "@/context/appContext";
import Script from "next/script";
import ClientRoot from "@/component/utils/ClientRoot";
import { NotificationProvider } from "@/context/notificationContext";
import { ChatProvider } from "@/context/chatContext";

export const metadata: Metadata = {
    metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL as string),
    title: "Bashable.art",
    description:
        "Bashable is an AI tool to generate beautiful realstic images.",
    openGraph: {
        type: "website",
        url: process.env.NEXT_PUBLIC_SITE_URL,
        siteName: "Bashable.art",
        title: "Bashable.art",
        description:
            "Bashable is an AI tool to generate beautiful realstic images",
        images: "/images/hero-images.png",
    },
};

export default function RootLayout({ children }: { children: ReactNode }) {
    return (
        <html lang="en" className="dark">
            <head>
                <Script
                    src="https://www.googletagmanager.com/gtag/js?id=G-QWFXGTWD21"
                    strategy="afterInteractive"
                />
                <Script id="google-analytics" strategy="afterInteractive">
                    {`
						window.dataLayer = window.dataLayer || [];
						function gtag(){window.dataLayer.push(arguments);}
						gtag('js', new Date());

						gtag('config', 'G-QWFXGTWD21');
                    `}
                </Script>
            </head>
            <body>
                <div id="modal-root"></div>
                <AuthProvider>
                    <AppProvider>
                        <NotificationProvider>
                            <ChatProvider>
                                <ClientRoot>{children}</ClientRoot>
                            </ChatProvider>
                        </NotificationProvider>
                    </AppProvider>
                </AuthProvider>
            </body>
        </html>
    );
}
