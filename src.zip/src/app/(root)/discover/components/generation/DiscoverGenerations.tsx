"use client";

import MasonryLayout from "@/component/shared/MasonryLayout";
import React, { useState } from "react";
import FiltersOptions from "./FilterOptions";

const DiscoverGenerations = () => {
    const [filterString, setFilterString] = useState<string>("");

    return (
        <React.Fragment>
            <div className="options mb-10">
                <FiltersOptions setFilterString={setFilterString} />
            </div>
            <div className="inner">
                <MasonryLayout
                    breakpoints={{
                        default: 7,
                        1790: 6,
                        1536: 5,
                        1320: 4,
                        1024: 3,
                        768: 2,
                        540: 1,
                    }}
                    url={`/public/discover/generations?limit=20${filterString}&`}
                    removeDeleteButton
                />
            </div>
        </React.Fragment>
    );
};

export default DiscoverGenerations;
