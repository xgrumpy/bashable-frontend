"use client";

import useFetch from "@/hooks/useFetch";
import React, { useState } from "react";
import FilterOptions from "./FilterOptions";
import UserItem from "./UserItem";

const DiscoverTopUsers = () => {
    const [isViewMore, setIsViewMore] = useState<boolean>(false);
    const [filterString, setFilterString] = useState<string>("");

    const { data: topUsers, refresh } = useFetch(
        `/public/discover/users?${filterString}${
            isViewMore ? "&extended=true" : ""
        }`,
        isViewMore
    );

    return (
        <div className="top-users space-y-2">
            <FilterOptions setFilterString={setFilterString} />
            {topUsers && Array.isArray(topUsers) && topUsers.length && (
                <React.Fragment>
                    {topUsers.map((user) => (
                        <UserItem key={user.id} user={user} refresh={refresh} />
                    ))}
                    <div className="text-center">
                        <button
                            className="btn mt-7"
                            onClick={() => setIsViewMore((prev) => !prev)}
                        >
                            {isViewMore ? "View Less" : "View More"}
                        </button>
                    </div>
                </React.Fragment>
            )}
        </div>
    );
};

export default DiscoverTopUsers;
