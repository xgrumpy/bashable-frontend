import Breadcrumb from "@/component/shared/Breadcrumb";
import DiscoverGenerations from "./components/generation/DiscoverGenerations";
import DiscoverTopUsers from "./components/users/DiscoverTopUsers";

const Discover = () => {
    return (
        <>
            <Breadcrumb title="Discover" />
            <main className="content">
                <section className="section pt-24 md:pt-32 lg:pt-40 pb-24 md:pb-32 lg:pb-40 bg-grey dark:bg-light">
                    <div className="px-4 md:px-8">
                        <h3 className="font-semibold text-3xl text-black dark:text-white mb-4">
                            Top Users
                        </h3>
                        <DiscoverTopUsers />
                    </div>
                    <span className="block mt-20"></span>
                    <div className="px-4 md:px-8">
                        <h3 className="font-semibold text-3xl text-black dark:text-white mb-4">
                            Generations
                        </h3>
                        <DiscoverGenerations />
                    </div>
                </section>
            </main>
        </>
    );
};

export default Discover;
