"use client";

import MasonryLayout from "@/component/shared/MasonryLayout";
import { useState } from "react";
import FiltersOptions from "./FilterOptions";

interface IProfileGenerationsProps {
    username: string;
}

const ProfileGenerations = ({ username }: IProfileGenerationsProps) => {
    const [filterString, setFilterString] = useState<string>("");

    return (
        <div className="px-4 md:px-8">
            <FiltersOptions setFilterString={setFilterString} />
            <span className="block mb-8"></span>
            <MasonryLayout
                breakpoints={{
                    default: 7,
                    1790: 6,
                    1536: 5,
                    1320: 4,
                    1024: 3,
                    768: 2,
                    540: 1,
                }}
                url={`/users/profile/${username}/generations?limit=20${filterString}&`}
                removeDeleteButton
            />
        </div>
    );
};

export default ProfileGenerations;
