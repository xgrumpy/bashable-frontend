import CustomSelect from "@/component/ui/CustomSelect";
import { ChangeEvent, useEffect, useState } from "react";
import { debounce, mapModelsToSelectItems } from "@/utils/utils";
import useFetch from "@/hooks/useFetch";
import { useAuthContext } from "@/context/authContext";

interface IFilterOptions {
    setFilterString: (str: string) => void;
}

const FiltersOptions = ({ setFilterString }: IFilterOptions) => {
    const [sortBy, setSortBy] = useState<string>("");
    const [selectedModel, setSelectedModel] = useState<string>("");
    const [searchPromptText, setSearchPromptText] = useState<string>("");
    const [mylikes, setMylikes] = useState<boolean>(false);
    const [featuredOnly, setFeaturedOnly] = useState<boolean>(false);

    const { unrestricted } = useAuthContext();
    const { data: models } = useFetch("/generate/checkpoints");

    useEffect(() => {
        let filters = `${selectedModel ? `model:${selectedModel},` : ""}${
            searchPromptText ? `prompt:${searchPromptText},` : ""
        }${featuredOnly ? `featured,` : ""}`.slice(0, -1);
        setFilterString(
            `${sortBy ? `&sortBy=${sortBy}` : ""}${
                filters ? `&filter=${filters}` : ""
            }${mylikes ? `&myLikes=${mylikes}` : ""}`
        );
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [sortBy, selectedModel, searchPromptText, mylikes, featuredOnly]);

    const handlePromptChange = (e: ChangeEvent<HTMLInputElement>) => {
        setSearchPromptText(e.target.value);
    };

    const debouncedPromptChange = debounce(handlePromptChange, 500);

    return (
        <div className="filters flex items-center flex-wrap gap-x-6 gap-y-3">
            <div className="optionitem flex items-center gap-2">
                <CustomSelect
                    items={[
                        { text: "Most Recent", value: "" },
                        { text: "Most Liked", value: "likes" },
                    ]}
                    current={sortBy}
                    setCurrentValue={setSortBy}
                />
            </div>
            <div className="optionitem flex items-center gap-2">
                <CustomSelect
                    items={mapModelsToSelectItems(models, unrestricted)}
                    current={selectedModel}
                    setCurrentValue={setSelectedModel}
                />
            </div>
            <div className="promptsearch">
                <input
                    className="!h-10"
                    type="text"
                    placeholder="Search by prompt text"
                    onChange={debouncedPromptChange}
                />
            </div>
            <div className="mylikes">
                <div className="flex items-center">
                    <div className="switchbox">
                        <input
                            type="checkbox"
                            id="enable-preprocessor"
                            checked={mylikes}
                            onChange={() => setMylikes((prev) => !prev)}
                        />
                        <label htmlFor="enable-preprocessor"></label>
                    </div>
                    <label
                        htmlFor="enable-preprocessor"
                        className="text-sm font-semibold text-black dark:text-white cursor-pointer"
                    >
                        My Likes
                    </label>
                </div>
            </div>
            <div className="featured">
                <div className="flex items-center">
                    <div className="switchbox">
                        <input
                            type="checkbox"
                            id="enable-featured-only"
                            checked={featuredOnly}
                            onChange={() => setFeaturedOnly((prev) => !prev)}
                        />
                        <label htmlFor="enable-featured-only"></label>
                    </div>
                    <label
                        htmlFor="enable-featured-only"
                        className="text-sm font-semibold text-black dark:text-white cursor-pointer"
                    >
                        Featured Only
                    </label>
                </div>
            </div>
        </div>
    );
};

export default FiltersOptions;
