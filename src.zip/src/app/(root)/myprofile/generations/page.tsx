"use client";

import MasonryLayout from "@/component/shared/MasonryLayout";
import FiltersOptions from "./components/FilterOptions";
import React, { useState } from "react";

const MyGenerations = () => {
    const [filterString, setFilterString] = useState<string>("");

    return (
        <React.Fragment>
            <div className="max-w-7xl mx-auto generations mt-10">
                <h4 className="text-2xl font-semibold text-black dark:text-white mb-5">
                    My Generations
                </h4>
            </div>
            <div className="px-4 md:px-8 mt-8">
                <div className="options mb-10">
                    <FiltersOptions setFilterString={setFilterString} />
                </div>
                <div className="inner">
                    <MasonryLayout
                        breakpoints={{
                            default: 7,
                            1790: 6,
                            1536: 5,
                            1320: 4,
                            1024: 3,
                            768: 2,
                            540: 1,
                        }}
                        url={
                            filterString
                                ? `/users/generations?limit=16${filterString}&`
                                : `/users/generations?limit=16&`
                        }
                    />
                </div>
            </div>
        </React.Fragment>
    );
};

export default MyGenerations;
