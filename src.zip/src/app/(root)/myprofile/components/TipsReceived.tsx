"use client";

import useFetch from "@/hooks/useFetch";
import Image from "next/image";
import Link from "next/link";
import TipItem from "./TipItem";

const TipsReceived = () => {
    const { data: tipsReceived } = useFetch("/users/tips/received");

    return (
        <div className="tips-sent space-y-2">
            {tipsReceived &&
                Array.isArray(tipsReceived) &&
                !tipsReceived.length && (
                    <p className="text-center">No items found</p>
                )}
            {tipsReceived &&
                Array.isArray(tipsReceived) &&
                tipsReceived.map((item: any) => (
                    <TipItem
                        key={item.id}
                        id={item.id}
                        amount={item.amount}
                        createdAt={item.createdAt}
                        avatar={item.sender.avatar}
                        username={item.sender.username}
                    />
                ))}
        </div>
    );
};

export default TipsReceived;
