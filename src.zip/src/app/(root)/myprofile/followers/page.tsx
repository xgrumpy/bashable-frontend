"use client";

import useFetch from "@/hooks/useFetch";
import UserItem from "../../search/user/components/UserItem";

const UserFollowersPage = () => {
    const { data: followers, refresh } = useFetch(`/users/followers`);

    const mapToUserData = (item: {
        following: boolean;
        info: {
            avatar: string | null;
            id: string;
            username: string;
        };
    }) => {
        return {
            ...item.info,
            following: item.following,
            followed: true,
        };
    };

    return (
        <div className="max-w-7xl mx-auto generations mt-10">
            <h4 className="text-2xl font-semibold text-black dark:text-white mb-5">
                My Followers
            </h4>
            <div className="flex flex-wrap mt-8 space-y-2">
                {followers &&
                    followers.map((user: any) => (
                        <UserItem
                            key={user.username}
                            data={mapToUserData(user)}
                            refresh={refresh}
                            showFollowed
                        />
                    ))}
            </div>
        </div>
    );
};

export default UserFollowersPage;
