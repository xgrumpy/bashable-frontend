"use client";

import PopupImage from "@/component/shared/PopupImage";
import useFetch from "@/hooks/useFetch";
import { memo, useEffect, useState } from "react";

const RecentCreations = ({ limit = 25 }: { limit?: number }) => {
    const [isMounted, setIsMounted] = useState(false);
    const [isPaused, setIsPaused] = useState<boolean>(false);

    const { data: responseData, refresh } = useFetch(`/public/showcase`);

    const modalStateReceiver = (state: boolean) => {
        setIsPaused(state);
    };

    useEffect(() => {
        setIsMounted(true);
    }, []);

    useEffect(() => {
        let interval: any;
        if (!isPaused) {
            interval = setInterval(() => {
                refresh();
            }, 10000);
        }
        return () => clearInterval(interval);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isPaused]);

    if (!isMounted) return null;

    return (
        <div className="recentcreation">
            {responseData && Array.isArray(responseData) && (
                <>
                    {responseData.length ? (
                        <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
                            <>
                                {responseData
                                    .slice(0, limit)
                                    .map((recentItem, index) => (
                                        <div key={recentItem.createdAt + index}>
                                            <PopupImage
                                                imageData={recentItem}
                                                refresh={refresh}
                                                removeDelete
                                                square
                                                modalStatePasser={
                                                    modalStateReceiver
                                                }
                                            />
                                        </div>
                                    ))}
                            </>
                        </div>
                    ) : (
                        <p className="text-center">There is no items to show</p>
                    )}
                </>
            )}
        </div>
    );
};

export default memo(RecentCreations);
