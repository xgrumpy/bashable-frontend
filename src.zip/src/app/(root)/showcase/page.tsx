"use client";

import Breadcrumb from "@/component/shared/Breadcrumb";
import MasonryLayout from "@/component/shared/MasonryLayout";
import { useState } from "react";
import FiltersOptions from "./components/FilterOptions";

const ShowcasePage = () => {
    const [filterString, setFilterString] = useState<string>("");

    return (
        <>
            <Breadcrumb title="Showcase" />
            <main className="content">
                <section className="section pt-24 md:pt-32 lg:pt-40 pb-24 md:pb-32 lg:pb-40 bg-grey dark:bg-light">
                    <div className="px-4 md:px-8">
                        <div className="options mb-10">
                            <FiltersOptions setFilterString={setFilterString} />
                        </div>
                        <div className="inner">
                            <MasonryLayout
                                breakpoints={{
                                    default: 7,
                                    1790: 6,
                                    1536: 5,
                                    1320: 4,
                                    1024: 3,
                                    768: 2,
                                    540: 1,
                                }}
                                url={`/public/explore?limit=20${filterString}&`}
                                removeDeleteButton
                            />
                        </div>
                    </div>
                </section>
            </main>
        </>
    );
};

export default ShowcasePage;
