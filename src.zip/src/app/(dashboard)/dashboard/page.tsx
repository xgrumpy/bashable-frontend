"use client";

import { useAuthContext } from "@/context/authContext";
import { redirect } from "next/navigation";
import { useEffect } from "react";

const Dashboard = () => {
    const { role } = useAuthContext();

    useEffect(() => {
        role === "admin" && redirect("/dashboard/users");
        role === "mod" && redirect("/dashboard/generations");
    }, [role]);

    return <main className="min-h-screen"></main>;
};

export default Dashboard;
