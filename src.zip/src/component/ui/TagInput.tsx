import React, {
    ChangeEvent,
    KeyboardEvent,
    SyntheticEvent,
    useState,
} from "react";
import { RiCloseLine } from "react-icons/ri";

interface ITagInputProps {
    tags: string[];
    setTags: React.Dispatch<React.SetStateAction<string[]>>;
}

const TagInput = ({ tags, setTags }: ITagInputProps) => {
    const [error, setError] = useState<string>("");
    const [inputText, setInputText] = useState<string>("");

    const checkError = (checkValue: string) => {
        if (tags.find((item) => item === checkValue)) {
            setError("Can't add duplicate item!");
            return true;
        } else {
            setError("");
            return false;
        }
    };

    const handleInputChange = (event: ChangeEvent<HTMLInputElement>) => {
        setInputText(event.target.value);
        setError("");
    };

    const enterKeyHandler = (event: KeyboardEvent<HTMLInputElement>) => {
        if (event.key === "Enter" && event.currentTarget.value !== "") {
            event.preventDefault();
            if (!checkError(event.currentTarget.value)) {
                setTags((prev) => [...prev, inputText]);
                setInputText("");
            }
        }
        return;
    };

    const handleRemove = (e: SyntheticEvent, value: string) => {
        e.preventDefault();
        setTags((prev) => prev.filter((item) => item !== value));
    };

    return (
        <div className="tag-input">
            {tags && tags.length ? (
                <div className="flex flex-wrap gap-1.5 mb-3">
                    {tags.map((item) => (
                        <button
                            key={item}
                            className="relative outline-0 border transition duration-300 bg-opacity-100 hover:bg-opacity-80 text-sm tracking-wide md:tracking-wider font-medium capitalize inline-block font-sans text-primary rounded-md overflow-hidden disabled:bg-opacity-75 px-3 md:px-4 py-1.5 border-primary bg-transparent hover:border-red-500 hover:text-red-500"
                            title="Click to remove"
                            onClick={(e) => handleRemove(e, item)}
                        >
                            {item}
                        </button>
                    ))}
                </div>
            ) : null}
            <input
                type="text"
                placeholder="Add new"
                value={inputText}
                onChange={handleInputChange}
                onKeyDown={enterKeyHandler}
            />
            {error ? (
                <p className="message text-red-500 mt-1">{error}</p>
            ) : null}
        </div>
    );
};

export default TagInput;
