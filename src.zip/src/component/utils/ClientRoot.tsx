"use client";

import { useAuthContext } from "@/context/authContext";
import { useChatContext } from "@/context/chatContext";
import { useNotificationContext } from "@/context/notificationContext";
import { ReactNode, useEffect } from "react";
import { RecoilRoot } from "recoil";

interface IClientRootProps {
    children: ReactNode;
}

const ClientRoot = ({ children }: IClientRootProps) => {
    const { username, updateCredits } = useAuthContext();
    const { addNotification } = useNotificationContext();
    const { isTypingOff, addMessage } = useChatContext();

    useEffect(() => {
        if (username) {
            const eventSource = new EventSource(`${process.env.NEXT_PUBLIC_API_URL}/sse`, {
                withCredentials: true,
            });

            eventSource.addEventListener("tip", (event) => {
                const eventData = JSON.parse(event.data);
                addNotification({
                    data: eventData.data,
                    createdAt: eventData.createdAt,
                    id: eventData.id,
                    read: false,
                    type: "tip",
                });

                updateCredits({
                    credits: eventData.data.amount,
                    method: "increment",
                });
            });

            eventSource.addEventListener("recharging_auto", (event) => {
                const eventData = JSON.parse(event.data);
                addNotification({
                    data: eventData.data,
                    createdAt: eventData.createdAt,
                    id: eventData.id,
                    read: false,
                    type: "recharging_auto",
                });
            });

            eventSource.addEventListener("recharging_auto_failed", (event) => {
                const eventData = JSON.parse(event.data);
                addNotification({
                    data: eventData.data,
                    createdAt: eventData.createdAt,
                    id: eventData.id,
                    read: false,
                    type: "recharging_auto_failed",
                });
            });

            eventSource.addEventListener("recharged", (event) => {
                const eventData = JSON.parse(event.data);
                addNotification({
                    data: eventData.data,
                    createdAt: eventData.createdAt,
                    id: eventData.id,
                    read: false,
                    type: "recharged",
                });
                updateCredits({
                    credits: parseFloat(eventData.data.credits),
                    method: "increment",
                });
            });

            eventSource.addEventListener("chat_reply", (event) => {
                const eventData = JSON.parse(event.data);
                isTypingOff();
                addMessage(eventData.reply);
                if (eventData.cost) {
                    updateCredits({
                        credits: eventData.cost,
                        method: "decrement",
                    });
                }
            });

            // eventSource.addEventListener("event_name", (event) => {});

            return () => {
                eventSource.close();
            };
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [username]);

    return <RecoilRoot>{children}</RecoilRoot>;
};

export default ClientRoot;
