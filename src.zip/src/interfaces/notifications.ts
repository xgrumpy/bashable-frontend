export type TNotificationType =
    | "tip"
    | "recharging_auto"
    | "recharging_auto_failed"
    | "recharged";

export type INotificationTip = {
    amount: number;
    sender: string;
};

export type INotificationRechargingAuto = {
    credits: number;
};
export type INotificationRechargingAutoFailed = {};
export type INotificationRecharged = {
    credits: number;
    platform: string;
};

export interface INotification {
    data: INotificationTip &
        INotificationRechargingAuto &
        INotificationRechargingAutoFailed &
        INotificationRecharged;
    createdAt: string;
    id: string;
    read: boolean;
    type: TNotificationType;
}
