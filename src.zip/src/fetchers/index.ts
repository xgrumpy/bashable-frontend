import axiosReq from "@/utils/axios";

export const getRecentCreations = async () => {
    const res = await axiosReq.get("/public/showcase");
    return res.data;
};
